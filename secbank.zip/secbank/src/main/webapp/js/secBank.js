function loadTransferForm(userName, container) {

    $.ajax({
        url: "transferForm?",
        data: {
            userName: userName
        },
        type: "GET",
        dataType: "html",
        success: function (data) {
            container.html(data);
            postAjax(container.children('form'), container);
        },
        error: function (xhr, status) {
            alert("Sorry, there was a problem!");
        },
        complete: function (xhr, status) {
        }
    });

};

function postAjax(form, container) {

    form.submit(function (event) {
        event.preventDefault(); //prevent default action
        var post_url = form[0].action; //get form action url
        var request_method = "GET"; //get form GET/POST method
        var form_data = form.serialize(); //Encode form elements for submission

        $.ajax({
            url: post_url,
            type: request_method,
            data: form_data,
            async: true
        }).done(function (response) { //

            if(response.result == 'SUCCESS') {

                alert(response.message);
                window.location.replace("/userHome");
            }else{
                alert(response.message);
            }

        }).error(
            function (xhr, status) {
                alert("Sorry, there was a problem: "+status);
            }
        );
    });

}


function loadTransferList(userName, container) {

    $.ajax({
        url: "transferList",
        data: {
            userName: userName
        },
        type: "GET",
        dataType: "html",
        success: function (data) {
            container.html(data);

        },
        error: function (xhr, status) {
            alert("Sorry, there was a problem!");
        },
        complete: function (xhr, status) {
        }
    });

};

function loadSimple(container, url) {

    $.ajax({
        url: url,
        type: "GET",
        dataType: "html",
        success: function (data) {
            container.html(data);

        },
        error: function (xhr, status) {
            alert("Sorry, there was a problem!");
        },
        complete: function (xhr, status) {
        }
    });

};

function loadForm(container, formUrl) {

    $.ajax({
        url: formUrl,
        type: "GET",
        dataType: "html",
        success: function (data) {
            container.html(data);

        },
        error: function (xhr, status) {
            alert("Sorry, there was a problem!");
        },
        complete: function (xhr, status) {
        }
    });

};

function fire_ajax_submit(actionUrl) {

    // Get form
    var form = $('form#newsPostForm')[0];

    var data = new FormData(form);

    $("#btnSubmit").prop("disabled", true);

    $.ajax({
        type: "POST",
        enctype: 'multipart/form-data',
        url: actionUrl,
        data: data,

        processData: false,
        contentType: false,
        cache: false,
        timeout: 600000,
        success: function (data) {

            if(data.result == 'SUCCESS') {

                alert(data.message);
                $("#btnSubmit").prop("disabled", false);
                window.location.replace("/userHome");
            }else{
                alert(data.message);
                $("#btnSubmit").prop("disabled", false);
            }

        },
        error: function (e) {

            alert( "ERROR : " + e.responseText);
            console.log("ERROR : ", e);
            $("#btnSubmit").prop("disabled", false);


        }
    });
}

