package com.secbank.domain;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Data
public class NewsPost {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private String id;

    @Column
    @Size(min=5, max=240)
    @NotNull
    private String title;

    @Column
    private String body;

    @Column
    private String imageURL;

    @Column
    private String link;

    @Column
    private String style; //TODO unassigned string to default css style "for future use"
}
