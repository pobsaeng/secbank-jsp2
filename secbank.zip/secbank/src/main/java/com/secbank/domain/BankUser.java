package com.secbank.domain;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;


@NamedNativeQueries({
        @NamedNativeQuery(name = "selectByUserName",
                query = "select * from bank_user where user_name= '?'"),
        
        @NamedNativeQuery(name = "selectList",
        query = "select * from bank_user where user_name= '?'"),
        
        @NamedNativeQuery(name = "selectUpdate",
        query = "update bank_user set password='?' where id='?'"),
})


@Entity
@Data
public class BankUser implements Serializable{

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(unique = true)
    private String userName;

    @Column(name="password")
    private String password;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name="USER_ROLE",
            joinColumns=@JoinColumn(name="USER_ID", referencedColumnName="ID"),
            inverseJoinColumns=@JoinColumn(name="ROLE_ID", referencedColumnName="ID"))
    private List<BankRole> roles;

    @OneToOne(mappedBy = "user")
    private BankAccount account;

    
    
    @Override
    public String toString() {
        return "BankUser{" +
                "id=" + id +
                ", userName='" + userName + '\'' +
                '}';
    }

    public boolean hasRole(String roleName){
        for (BankRole role: getRoles()) {
            if(role.getId().equals(roleName))
                return true;
        }
        return false;
    }
}
