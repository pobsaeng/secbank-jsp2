package com.secbank.domain;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.io.Serializable;


@Entity
@Data
public class AccountTransfer implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private String id;

    @ManyToOne
    private BankAccount accountSource;

    @ManyToOne
    private BankAccount accountDestination;

    private Float amount;

    private String reference;

    @Temporal(TemporalType.TIMESTAMP)
    private java.util.Date creationTime;

    @Column
    private Boolean suspicious = null;



}
