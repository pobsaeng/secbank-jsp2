package com.secbank;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.Filter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionListener;
import javax.transaction.Transactional;

import org.apache.catalina.servlet4preview.http.HttpFilter;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Bean;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.secbank.domain.BankAccount;
import com.secbank.domain.BankRole;
import com.secbank.domain.BankUser;


/*
This calss in out of the scope of the hackathon review
 */

@Component
public class StartUpInit implements ApplicationListener<ContextRefreshedEvent> {

	
    @PersistenceContext
    private EntityManager em;

    @Bean
    public HttpSessionListener HttpSessionListener() {
    	return new MyHttpSessionListener();
    }
    
//    @Bean
//    public Filter HttpFilter(HttpServletRequest request) {
//    	return null;
//    }
    

    @Transactional
    public void onApplicationEvent(ContextRefreshedEvent event) {

        //Init roles
        {

    		
            BankRole adminRole = new BankRole("admin");
            em.persist(adminRole);
            //Init admin user
            BankUser adminUser =  createBankUser("admin",deCrypAES("AejYeEixDDGFQjHMtlA8pA=="), 10000f, Arrays.asList(adminRole), false);

        }

        //Init customers users and accounts
        {
            BankRole customerRole = new BankRole("customer");
            em.persist(customerRole);

            List<BankRole> roles = new ArrayList<BankRole>(1);
            roles.add(customerRole); 

            
            BankUser customerUser1 = createBankUser("customer1", deCrypAES("65IpgzVzaJSzWqeu6ieb6A=="), 10000f, roles, true);
            BankUser customerUser2 = createBankUser("customer2", deCrypAES("65IpgzVzaJSzWqeu6ieb6A=="), 20000f, roles, true);
            BankUser customerUser3 = createBankUser("customer3", deCrypAES("65IpgzVzaJSzWqeu6ieb6A=="), 30000f, roles, true);

        }
    }

    private BankUser createBankUser(String userName, String password, Float balance, List<BankRole> roles, boolean createAccount) {

        BankUser customerUser = new BankUser();
        customerUser.setUserName(userName);
        customerUser.setPassword(password);

        customerUser.setRoles(roles);

        em.persist(customerUser);

        if(createAccount)
        {
            BankAccount account = new BankAccount();
            account.setBalance(balance);
            account.setUser(customerUser);
            em.persist(account);
        }
        return customerUser;
    }   

    
    private String deCrypAES(String pass) {
    	String login_SecreKey = "UWA@2093CYq7901_"; // 128 bit key
		String login_IvParameter = "Jies10IEQISBCU03"; // 16 bytes IV
    	String secrePass = decrypt(login_SecreKey,login_IvParameter,pass);		
		
		if (getSHADecryption(secrePass)){
			return secrePass;
		}else {
			return pass;
		}
		

    }
    
    public String decrypt(String key, String initVector, String encrypted) {
		try {
			IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
			SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");

			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);

			byte[] decryptedData = new sun.misc.BASE64Decoder().decodeBuffer(encrypted);
			byte[] original = cipher.doFinal(decryptedData);

			return new String(original);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return null;
	}
    //==================================================================
    private static final String ALGORITHM = "SHA-512"; 
    private static final int ITERATIONS = 1000000; 
    private static final int SALT_SIZE = 64; 
    private byte[] generateSalt() { 
        SecureRandom random = new SecureRandom(); 
        byte[] salt = new byte[SALT_SIZE]; 
        random.nextBytes(salt); 
 
        return salt; 
    } 
    private boolean getSHADecryption(String password){
    	boolean status = false;
    	try { 
            byte[] salt = generateSalt(); 
            byte[] hash = calculateHash(password, salt);                
            boolean correct = verifyPassword(hash, password, salt); 
            if(correct){
            	System.out.println("correct : " + correct);
            	status= true;
            	
            }
 
        } catch (NoSuchAlgorithmException | UnsupportedEncodingException ex) { 

        } 
    	return status;
    }
    private byte[] calculateHash(String password, byte[] salt) throws NoSuchAlgorithmException, 
            UnsupportedEncodingException { 
        MessageDigest md = MessageDigest.getInstance(ALGORITHM); 
        md.reset(); 
        //md.update(Bytes.concat(password.getBytes("UTF-8"), salt)); 
        md.update(password.getBytes("UTF-8"));
        byte[] hash = md.digest(); 
 
        for (int i = 0; i < ITERATIONS; i++) { 
            md.reset(); 
            hash = md.digest(hash); 
        } 
 
        return hash; 
    } 
 
    private boolean verifyPassword(byte[] originalHash, String password, byte[] salt) throws 
            NoSuchAlgorithmException, UnsupportedEncodingException { 
        byte[] comparisonHash = calculateHash(password, salt); 
 

        return comparePasswords(originalHash, comparisonHash); 
    } 
 
    private boolean comparePasswords(byte[] originalHash, byte[] comparisonHash) { 
        int diff = originalHash.length ^ comparisonHash.length; 
        for (int i = 0; i < originalHash.length && i < comparisonHash.length; i++) { 
            diff |= originalHash[i] ^ comparisonHash[i]; 
        } 
 
        return diff == 0; 
    } 
    
    
    

}