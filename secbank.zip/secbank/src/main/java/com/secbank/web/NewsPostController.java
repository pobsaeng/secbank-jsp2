package com.secbank.web;

import com.secbank.domain.NewsPost;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;
import javax.validation.Valid;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

@Slf4j
@Controller
@RequestMapping("/newsPost")
public class NewsPostController {


    @PersistenceContext
    private EntityManager em;

    @Transactional
    @RequestMapping(value = "/form", method = RequestMethod.GET)
    public String createBankAccountPost(HttpServletRequest request, String userName, Map<String, Object> model) {

        model.put("newsPost", new NewsPost());

        return "includes/newsPostForm";
    }

    @Transactional
    @RequestMapping(value = "/delete/{id}")
    public String transferAction(HttpServletRequest request, @PathVariable String id,
                                 Map<String, Object> model) throws IOException {

        em.createQuery("delete from NewsPost where id = :id").setParameter("id", id).executeUpdate();
        return "redirect:/userHome#home";
    }


    @Transactional
    @RequestMapping(value = "/create")
    @ResponseBody
    public ActionResult create(HttpServletRequest request,
                               @Valid NewsPost newsPost,
                               BindingResult validationResult,
                               @RequestParam(value = "file", required = false) MultipartFile file,
                               Map<String, Object> model) throws IOException {

        ActionResult result = new ActionResult();

        if (!validationResult.hasErrors()) {
            if (!file.isEmpty()) {

                    String folder = request.getSession().getServletContext().getRealPath("/newsAttachments/");
                    byte[] bytes = file.getBytes();
                    Path path = Paths.get(folder + file.getOriginalFilename());
                    Files.write(path, bytes);
                    //Process image
                    //Resize image
                    String resizedFolder = folder + "resized/";
                    String cmd = "/usr/local/bin/convert " + path + "   -resize 64x64  " + resizedFolder + file.getOriginalFilename();

                    Process p = Runtime.getRuntime().exec(cmd);

                    newsPost.setImageURL("/newsAttachments/resized/" + file.getOriginalFilename());

            }

            em.persist(newsPost);
            result.setResult(ActionResult.Result.SUCCESS);
            result.setMessage("Post created successfully");

            return result;

        } else {

            model.put("newsPost", newsPost);

            String errorMessage = "";
            List<ObjectError> errors = validationResult.getAllErrors();
            for (ObjectError e : errors) {

                errorMessage += "ERROR: " + e.getDefaultMessage() + ", value: " + ((FieldError) e).getRejectedValue() + "\n";
            }
            model.put("errorMessage", errorMessage);

            result.setResult(ActionResult.Result.FAIL);
            result.setMessage(errorMessage);
            return result;
        }

    }


    @Transactional
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public String transferList(Map<String, Object> model) {
        List<NewsPost> list =
                em.createQuery("FROM NewsPost order by id desc").getResultList();
        model.put("list", list);
        return "includes/newsPost/list";
    }

}
