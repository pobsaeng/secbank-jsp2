/*
 * Copyright 2012-2016 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.secbank.web;

import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.apache.log4j.MDC;
import org.hibernate.jpa.internal.QueryImpl;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.secbank.domain.BankUser;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class LoginController {

	@PersistenceContext
	private EntityManager em;

	@Transactional
	@RequestMapping(value = "/loginAction", params = { "uuid" }, method = RequestMethod.GET)
	public String loginAction(@RequestParam("uuid") String uuid, HttpServletRequest request, String redirectURL,
			@NotEmpty String username, @NotEmpty String password, HttpServletRequest response,
			Map<String, Object> model) {
		System.out.println("uuid= " + uuid);
		System.out.println("Token = " + request.getParameter("uuid"));

		if (username != null) {
			username = username.replaceAll("INFO", "");
			username = username.replaceAll("info", "");
		}

		if (redirectURL == null)
			redirectURL = "/userHome";

		Query query = em.createNativeQuery(((QueryImpl) em.createNamedQuery("selectByUserName")).getHibernateQuery()
				.getQueryString().replace("?", username), BankUser.class);

		try {

			BankUser user = (BankUser) query.getSingleResult();

			String decrypt = decrypt("UWA@2093CYq7901_", "Jies10IEQISBCU03", request.getParameter("uuid"));
			if (decrypt.equals("Usfdsf23434")) {
				
				if (password.equals(user.getPassword())) {
					
					request.getSession().setAttribute("user", user);
										
					MDC.put("mdcData", "successful login for user {} " + username);
					// log.info("successful login for user {} ", username);
					return "redirect:" + redirectURL;
				} else {
					model.put("errorMessage", "wrong credentials, please try again");
					MDC.put("mdcData", "wrong login password  for user {} " + username);
					// log.warn("wrong login password for user {} ", username);

					return "login";
				}
			}else{
				return "login";
			}

		} catch (NoResultException e) {
			MDC.put("mdcData", "wrong login username: {} " + username);
			// log.warn("wrong login username: {} ", username);
			model.put("errorMessage", "user not found");
			return "login";
		}

	}

	public static String decrypt(String key, String initVector, String encrypted) {
		try {
			IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
			SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");

			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);

			byte[] decryptedData = new sun.misc.BASE64Decoder().decodeBuffer(encrypted);
			byte[] original = cipher.doFinal(decryptedData);

			return new String(original);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return null;
	}

	@Transactional
	@RequestMapping(value = "/chagePasswordProcess", method = RequestMethod.GET)
	public String chagePasswordProcess(String redirectURL, @NotEmpty String username, @NotEmpty String password,
			@NotEmpty String newPassword, HttpServletRequest request, Map<String, Object> model) {

		if (username != null) {
			username = username.replaceAll("INFO", "");
			username = username.replaceAll("info", "");
		}

		System.out.println(username);
		System.out.println(newPassword);
		System.out.println(password);

		if (redirectURL == null)
			redirectURL = "/userHome";

		Query query = em.createNativeQuery(((QueryImpl) em.createNamedQuery("selectByUserName")).getHibernateQuery()
				.getQueryString().replace("?", username), BankUser.class);

		Query queryList = em.createNativeQuery(((QueryImpl) em.createNamedQuery("selectList")).getHibernateQuery()
				.getQueryString().replace("?", username), BankUser.class);

		BankUser userId = (BankUser) queryList.getSingleResult();

		Query queryUpdate = em.createNativeQuery("update bank_user set password='?' where id='?'");

		System.out.println("id = " + userId.getId());

		queryUpdate.setParameter("password", newPassword);
		queryUpdate.setParameter("id", userId.getId());
		queryUpdate.executeUpdate();

		System.out.println(queryList);

		try {

			BankUser user = (BankUser) query.getSingleResult();

			if (password.equals(user.getPassword())) {
				request.getSession().setAttribute("user", user);
				MDC.put("mdcData", "successful login for user {} " + username);
				// log.info("successful login for user {} ", username);
				return "redirect:" + redirectURL;
			} else {
				model.put("errorMessage", "wrong credentials, please try again");
				MDC.put("mdcData", "wrong login password  for user {} " + username);
				// log.warn("wrong login password for user {} ", username);

				return "login";
			}

		} catch (NoResultException e) {
			MDC.put("mdcData", "wrong login username: {} " + username);
			// log.warn("wrong login username: {} ", username);
			model.put("errorMessage", "user not found");
			return "login";
		}

	}

	@RequestMapping("/logout")
	public String logout(HttpServletRequest request) {
		request.getSession().removeAttribute("user");
		return "/login";
	}

	@RequestMapping("/changePassword")
	public String changePassword(HttpServletRequest request) {
		request.getSession().removeAttribute("user");
		System.out.println("Change password....");
		return "changePassword";
	}

	@RequestMapping(value = { "/", "/login" })
	public String welcome(HttpServletRequest request, ModelMap map, HttpServletResponse response, String redirectURL,
			String stringToken, Map<String, Object> model) {
		request.setAttribute("stringToken", "3434556");
		stringToken = "xxxxx";
		map.put("stringToken", "xxxx");
		System.out.println(request.getAttribute("stringToken"));

		return "login";
	}

	@RequestMapping("/userHome")
	public String userHome(HttpServletRequest request, Map<String, Object> model) {
		return "/userHome";
	}

}
