package com.secbank.web;

import lombok.Data;


@Data
public class ActionResult {

    String message;
    Result result;

    public enum Result {FAIL, SUCCESS};


}

