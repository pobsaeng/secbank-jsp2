package com.secbank.web;

import com.secbank.domain.AccountTransfer;
import com.secbank.domain.BankAccount;
import com.secbank.domain.BankUser;
import lombok.extern.slf4j.Slf4j;

import org.apache.log4j.MDC;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;
import javax.validation.Valid;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Slf4j
@Controller
public class TransferController {

	@PersistenceContext
	private EntityManager em;


	@Transactional
	@RequestMapping(value = "/transferForm", method = RequestMethod.GET)
	public String transferForm(HttpServletRequest request, String userName, Map<String, Object> model) {		
		
		HttpSession session = request.getSession();		
		
		BankUser bankUser = (BankUser) request.getSession().getAttribute("user");
		Query query = em.createQuery("From BankAccount ba where ba.user.userName != :bankUser ")
				.setParameter("bankUser", userName);
		List<BankAccount> beneficiaries = query.getResultList();
		model.put("beneficiaries", beneficiaries);
		
		if (session.isNew()) {
			MDC.put("mdcData", "New session pleas go away...");
			return "/logout";
		}
		
		return "includes/transferForm";
	}
		

	@Transactional
	@RequestMapping(value = "/transferList", method = RequestMethod.GET)
	public String transferList(HttpServletRequest request, String userName, Map<String, Object> model) {
		HttpSession session = request.getSession();		
		List<AccountTransfer> transfersList =
				em.createQuery("FROM AccountTransfer where " +
						"accountSource.user.userName = :userName OR " +
						"accountDestination.user.userName = :userName order by id")
						.setParameter("userName", userName).getResultList();

		model.put("transfers", transfersList);
		if (session.isNew()) {
			MDC.put("mdcData", "New session pleas go away...");
			return "/logout";
		}
		return "includes/transferList";
	}
	
	private boolean validateFiles(Float value){
		String f = String.valueOf(value);
		
		
		if(f == null || f.equalsIgnoreCase("")||f.length()<1 ){
			return false;
		}
		if(f.length() < 1 || !f.matches("^[a-zA-Z0-9]")){
			return false;
		}
		
		return  true;
	}

	@Transactional
	@RequestMapping(value = "/transferAction")
	@ResponseBody
	public ActionResult transferAction(HttpServletRequest request, String userAccountId, String beneficiary, @Valid AccountTransfer accountTransfer, BindingResult validationResult, Map<String, Object> model) {
		ActionResult transferResult = new ActionResult();
		HttpSession session = request.getSession();	

		if (!validationResult.hasErrors()) {
			
			BankUser bankUser = (BankUser) request.getSession().getAttribute("user");

			//BankAccount sourceAccount= (BankAccount) em.createQuery("FROM BankAccount WHERE id = '" + userAccountId + "'").getSingleResult();
			
			
			BankAccount beneficiaryAccount = (BankAccount) em.createQuery("FROM BankAccount WHERE user.userName = '" + beneficiary + "'").getSingleResult();
			if(validateFiles(accountTransfer.getAccountSource().getBalance())){
				accountTransfer.setAccountSource(accountTransfer.getAccountSource());
			}

			
			accountTransfer.setAccountDestination(beneficiaryAccount);
			
			if (beneficiaryAccount.getBalance()>0) {			
				beneficiaryAccount.setBalance(beneficiaryAccount.getBalance() + accountTransfer.getAmount());
			}else {
				transferResult.setMessage(" Balance: error " + beneficiaryAccount.getBalance());
				transferResult.setResult(ActionResult.Result.FAIL);
				return transferResult;
			}

			
			accountTransfer.getAccountSource().setBalance(accountTransfer.getAccountSource().getBalance() - accountTransfer.getAmount());

			bankUser.setAccount(accountTransfer.getAccountSource());


			accountTransfer.setCreationTime(new Date());

			em.merge(accountTransfer.getAccountSource());
			em.merge(accountTransfer);


			transferResult.setMessage("New available Balance: " + accountTransfer.getAccountSource().getBalance());
			transferResult.setResult(ActionResult.Result.SUCCESS);
			
			if (session.isNew()) {
				MDC.put("mdcData", "New session pleas go away...");
				transferResult.setMessage("New session pleas go away... ");
				transferResult.setResult(ActionResult.Result.FAIL);
			}
			return transferResult;//"ajax/transferCompleted";

		} else {
			String errorMessage = "";
			List<ObjectError> errors = validationResult.getAllErrors();
			for (ObjectError e : errors) {

				errorMessage += "ERROR: " + e.getDefaultMessage() + ", value: " + ((FieldError) e).getRejectedValue() + "\n";
			}
			transferResult.setMessage(errorMessage);
			transferResult.setResult(ActionResult.Result.FAIL);
			return transferResult;//"ajax/transferCompleted";

		}
	}


}
