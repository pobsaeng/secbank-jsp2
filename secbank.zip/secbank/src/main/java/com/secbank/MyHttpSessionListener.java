package com.secbank;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

@WebListener
public class MyHttpSessionListener implements HttpSessionListener {

	@Override
	public void sessionCreated(HttpSessionEvent se) {
		
			se.getSession().setMaxInactiveInterval(5*60);
		
		//System.out.println("Session----");
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent se) {	
			se.getSession().invalidate();
				//System.out.println("sessionDestroyed--");
		
	}

}

